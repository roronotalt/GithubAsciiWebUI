Silkscreen was created by Jason Kottke and is distributed under the Open Font License, which means that you can use, distribute, or modify it however you wish. More information about the license and Silkscreen is available on the web:

http://scripts.sil.org/OFL
http://www.kottke.org/plus/type/silkscreen/

To install Silkscreen, simply copy the two .ttf files to your fonts directory.